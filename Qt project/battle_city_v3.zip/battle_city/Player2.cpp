#ifndef PLAYER2_H
#define PLAYER2_H

#include <QGraphicsPixmapItem>

class Player2 : public QGraphicsPixmapItem
{
public:
    Player2();
};

#endif // PLAYER_H

