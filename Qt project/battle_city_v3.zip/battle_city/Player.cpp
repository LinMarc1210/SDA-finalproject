#include "Player.h"

Player::Player()
{
    setPixmap(QPixmap(":/images/player_1.png"));
}
