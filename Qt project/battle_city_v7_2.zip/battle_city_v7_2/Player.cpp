#include "Player.h"
#include <QGraphicsRectItem>
#include <QKeyEvent>
#include <QGraphicsPixmapItem>

Player::Player()
{
    setPixmap(QPixmap(":/images/Players/Player1.png").scaled(40,40));
    // setPixmap(QPixmap(":/images/Players/Player1.jpg").scaled(40,40));
}




//void Player::keyPressEvent1(int key)
//{
//    QPointF pos = this->pos();  // Assuming 'player' is the current instance
//    prev = pos; // prev 相當於記移動前的位置
//    setTransformOriginPoint(boundingRect().center());
//    QPointF nextpos = pos;

//    if (key == Qt::Key_Left ) {
//        this->current_player_Direction = 1;
//        setRotation(180); //
//        nextpos = pos + QPointF(-1, 0);
//    } else if (key == Qt::Key_Right) {
//        this->current_player_Direction = 2; // 改變方向為右邊
//        setRotation(0); // 右邊
//        nextpos = pos + QPointF(1, 0);
//    } else if (key == Qt::Key_Up) {
//        this->current_player_Direction = 3;
//        setRotation(-90); // 上面
//        nextpos = pos + QPointF(0, -1);
//    } else if (key == Qt::Key_Down) {
//        this->current_player_Direction = 4;
//        setRotation(90); // 下面
//        nextpos = pos + QPointF(0, 1);
//    }
//    setPos1(nextpos);

//    if (colliding) {
//        setPos1(getPrev());
//    }
//    else {
//        setPos1(nextpos);
//        qDebug() << nextpos << this->pos() << "prev = " << prev;
//    }

//    if (pos1 == prev){
//        colliding = false;
//    }

//    setPos(pos1);

//}

QPointF Player::getPrev() const
{
    return prev;
}

void Player::setPrev(QPointF newPrev)
{
    prev = newPrev;
}

QPointF Player::getPos1() const
{
    return pos1;
}

void Player::setPos1(QPointF newPos)
{
    pos1 = newPos;
}

bool Player::getColliding() const
{
    return colliding;
}

void Player::setColliding(bool newColliding)
{
    colliding = newColliding;
}

