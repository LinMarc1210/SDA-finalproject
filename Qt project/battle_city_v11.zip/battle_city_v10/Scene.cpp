#include "Scene.h"
#include <QGraphicsSceneMouseEvent>
#include <QKeyEvent>
#include <QFile>
#include <QDebug>
#include <QString>
#include <QVector>
#include <iostream>
Scene::Scene(QObject *parent):
    gameOn(false), score(0), bestScore(20000),level(1),
    scoreTextItem(nullptr)
{

    battleCityBigWord = new QGraphicsPixmapItem(QPixmap(":/images/Homepage/Battlecity_bigword.jpg"));
    addItem(battleCityBigWord);
    battleCityBigWord->setPos(215,150);

    file = new QGraphicsPixmapItem(QPixmap(":/images/Homepage/File.png").scaled(30,30));
    addItem(file);
    file->setPos(700,33);

    onePlayer = new QGraphicsPixmapItem(QPixmap(":/images/Homepage/Oneplayer.jpg"));
    addItem(onePlayer);
    onePlayer->setPos(300,350);

    twoPlayer = new QGraphicsPixmapItem(QPixmap(":/images/Homepage/Twoplayer.jpg"));
    addItem(twoPlayer);
    twoPlayer->setPos(300,400);

    playerChose = new QGraphicsPixmapItem(QPixmap(":/images/Players/Player1.png"));
    addItem(playerChose);
    qreal scale = 0.5;
    playerChose->setScale(scale);
    playerChose->setPos(250,345);
    pos = playerChose->pos();

    //到時候從setplayer那邊印跟選擇
    scoreTextItem = new QGraphicsTextItem();
    QString htmlString = "<p> I- : " + QString::number(score) + " HI- : " + QString::number(bestScore) + " </p>";
    QFont font("Consolas", 20, QFont::Bold);

    scoreTextItem->setHtml(htmlString);
    scoreTextItem->setFont(font);
    scoreTextItem->setDefaultTextColor(Qt::white);
    addItem(scoreTextItem);

    scoreTextItem->setPos(50,30);
}

Scene::~Scene()
{

}

void Scene::setPlayer(int newplayer)
{
    number = newplayer;
    //看傳來的player有幾位決定做什麼事
}

int Scene::getPlayer()
{
    return number;
}

void Scene::startGame()
{
    score = 0;
    setGameOn(true);
    // Start animation
}

bool Scene::getGameOn() const
{
    return gameOn;
}

void Scene::setGameOn(bool newGameOn)
{
    gameOn = newGameOn;
}

void Scene::keyPressEvent(QKeyEvent *event)
{
    if (!isChooseStage){
        if (event->key() == Qt::Key_Shift) {
            pos = playerChose->pos();
            if (pos == QPoint(250, 345)) {
                playerChose->setPos(250, 400);
            } else {
                playerChose->setPos(250, 345);
            }
            pos = playerChose->pos();  // 更新 pos 選擇的
        }//Shift選關
        if (event->key() == Qt::Key_Return) {    // 還在主畫面時按enter
            if (pos == QPoint(250, 345)) {
                setPlayer(1);
            } else {
                setPlayer(2);
            }
            isChooseStage = true;
            setLevel();
        }//按Enter決定幾player
    }
    else   // 進入選關畫面了
    {
        if (event->key() == Qt::Key_X) {
            if(level<2){
                level++;
            }
            setLevel();
        }
        if (event->key() == Qt::Key_Z) {
            if(level>1){
                level--;
            }
            setLevel();
        }
        if (event->key() == Qt::Key_Return) {    // 選關時按enter
            emit changeLevel();
        }
    }
    QGraphicsScene::keyPressEvent(event);
}

void Scene::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        QPointF clickPos = event->scenePos(); // 取得滑鼠點擊的位置

        QRectF onePlayerRect = onePlayer->sceneBoundingRect(); // 取得 onePlayer 物件的邊界
        if (onePlayerRect.contains(clickPos)) {
            setPlayer(1);
            setLevel();
            return;
        }

        QRectF twoPlayerRect = twoPlayer->sceneBoundingRect(); // 取得 twoPlayer 物件的邊界
        if (twoPlayerRect.contains(clickPos)) {
            setPlayer(2);
            setLevel();
            return;
        }

        QRectF fileRect = file->sceneBoundingRect();
        if (fileRect.contains(clickPos)){
            qDebug()<<"presss file button";
            readFile();
            return;
        }
    }
    QGraphicsScene::mousePressEvent(event);
}

void Scene::setLevel()
{
    levelChose = new QGraphicsPixmapItem(QPixmap(":/images/Homepage/Level_chose.png"));
    addItem(levelChose);
    qreal scale = 3.0;
    levelChose->setScale(scale);
    levelChose->setPos(0,0);

    levelTextItem = new QGraphicsTextItem();
    QString htmlString = "<p> STAGE : " + QString::number(level);
    //感覺要用timer去更新選擇level
    QFont font("Consolas", 20, QFont::Bold);

    levelTextItem->setHtml(htmlString);
    levelTextItem->setFont(font);
    levelTextItem->setDefaultTextColor(Qt::white);
    addItem(levelTextItem);
    levelTextItem->setPos(275,275);
}

int Scene::getLevel()
{
    return level;
}

int Scene::getScore() const
{
    return score;
}

void Scene::setScore(int newScore)
{
    score = newScore;
}

int Scene::getHealth() const
{
    return health;
}

void Scene::setHealth(int newHealth)
{
    health = newHealth;
}

vector<vector<char> > Scene::getMap() const
{
    return map;
}

void Scene::setMap(const vector<vector<char> > &newMap)
{
    map = newMap;
}

vector<vector<char> > Scene::getTank() const
{
    return tank;
}

void Scene::setTank(const vector<vector<char> > &newTank)
{
    tank = newTank;
}

void Scene::readFile()
{
    QFile file(":/files/tempFIle.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Can't open the file!";
        return ;
    }

    QTextStream in(&file);
    //取得level, 人數, 生命, 分數
    for (int i = 0; i < 4 && !in.atEnd(); ++i) {
        QString line = in.readLine();
        //將字串轉為數字
        bool ok;
        int value = line.toInt(&ok);
        if (ok) {
            if (i == 0){
                setPlayer(value); // 玩家人数
                qDebug()<<getPlayer();
            }else if (i == 1){
                level = value;       // 關卡(其實讀檔不需要它但connect要)
                qDebug()<<getLevel();
            }else if (i == 2){
                setHealth(value);
                qDebug()<<getHealth();
            }else if (i == 3){
                setScore(value);
                qDebug()<<getScore();
            }else
                qDebug()<<"轉換整數失敗"<<line;
        }
    }
    file.seek(0);

    QVector<QVector<char>> map;

    // 讀取檔案內容
    for (int i = 0; i <= 51 && !in.atEnd(); i++) {
        QString line = in.readLine();
        QVector<char> rowVector;

        for (int j = 0; j < line.length(); j++) {
            rowVector.push_back(line[j].toLatin1());
        }

        map.push_back(rowVector);
    }
    std::vector<std::vector<char>> stdMap;
    for (const auto& qRow : map) {
        std::vector<char> stdRow(qRow.begin(), qRow.end());
        stdMap.push_back(stdRow);
    }

    setMap(stdMap);


    vector<vector<char>> newTank; // 新的 vector

    // 讀取兩行
    for (int i = 0; i < 2 && !in.atEnd(); ++i) {
        QString line = in.readLine();
        vector<char> rowVector;

        for (int j = 0; j < line.length(); j++) {
            rowVector.push_back(line[j].toLatin1());
        }

        newTank.push_back(rowVector);
    }

    // 顯示轉換後的新地圖
    for (const auto& row : newTank) {
        for (char cell : row) {
            std::cout << cell;
        }
        std::cout << std::endl;
    }

    // 將新的地圖存入 newTank
    setTank(newTank);
    file.close();

    emit changeLevel_read();

    return;
}
