#ifndef SCENE_H
#define SCENE_H

#include <QGraphicsScene>
#include <QTimer>
#include <QGraphicsPixmapItem>
#include <vector>

using namespace std;

class Scene : public QGraphicsScene
{
    Q_OBJECT
public:
    explicit Scene(QObject *parent = nullptr);
    ~Scene();
    void startGame();
    bool getGameOn() const;
    void setGameOn(bool newGameOn);
    void setPlayer(int newplayer);
    int getPlayer();
    void setLevel();
    int getLevel();
    int number;
    void setBestScore(int bestScore)
    {
        score = bestScore;
    }
    int getScore() const;
    void setScore(int newScore);

    int getHealth() const;
    void setHealth(int newHealth);

    vector<vector<char> > getMap() const;
    void setMap(const vector<vector<char> > &newMap);

    vector<vector<char> > getTank() const;
    void setTank(const vector<vector<char> > &newTank);

    void readFile();

signals:
    void changeLevel();
    void changeLevel_read();

private:
    bool isChooseStage = false;
    bool gameOn;
    int score;
    int bestScore;
    //int player;
    int level;
    int health;
    vector<vector<char>> map;
    vector<vector<char>> tank;

    QPointF pos ;
    //在QGraphicsScene中就有PixmapItem, TextItem
    QGraphicsPixmapItem *battleCityBigWord;
    QGraphicsPixmapItem *onePlayer;
    QGraphicsPixmapItem *twoPlayer;
    QGraphicsPixmapItem *levelChose;
    QGraphicsPixmapItem *playerChose;
    QGraphicsPixmapItem *file;
    QGraphicsTextItem *scoreTextItem;
    QGraphicsTextItem *levelTextItem;

    // QGraphicsScene interface
protected:
    void keyPressEvent(QKeyEvent *event);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
};

#endif // SCENE_H
