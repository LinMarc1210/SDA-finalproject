#ifndef SCORE_H
#define SCORE_H

#include <QGraphicsTextItem>

class Score : public QGraphicsTextItem
{
public:
    Score();
    void increase(int points);
    void setScore(int newScore);
    int getScore();
private:
    int score;
};

#endif // SCORE_H
