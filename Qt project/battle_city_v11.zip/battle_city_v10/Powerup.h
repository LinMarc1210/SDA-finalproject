#ifndef POWERUP_H
#define POWERUP_H

#include <QGraphicsPixmapItem>

class Powerup : public QGraphicsPixmapItem {
public:
    Powerup(QGraphicsItem *parent = nullptr);
    int getType() const {
        return type;
    }
    int type ;
    QPixmap generatePixmap();
    void setPowerupPixmap(){

        setPixmap(generatePixmap().scaled(50,50));
    }

public slots:
    void collected();

private:


protected:


};

#endif // POWERUP_H
