#include "Wall.h"
#include "Flag.h"
#include "Level.h"
#include <QDebug>
#include "Bullet.h"
#include "Enemy.h"
#include <QGraphicsRectItem>
#include <QKeyEvent>
#include <QGraphicsPixmapItem>
#include "Player.h"
#include "Player2.h"
#include "Scene.h"
Level::Level(int level, int number)
    :remains(20),
    tanks({{'f', 'f', 'f', 'f', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'b', 'b', 'b', 'b', 'p', 'p', 'p', 'p'},
           {'p', 'p', 'p', 'p', 'f', 'f', 'f', 'f', 'f', 'f', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'b', 'b'}})

{
    star = 2;
    invincibleTimer = new QTimer(this);
    effectTimer = new QTimer(this);
    checkTimer = new QTimer(this);



    number_1=number;
    generateMap(level);
    qDebug() << "Invincible timer started!";
    setPlayer(number); //決定幾個玩家並生成在初始位置
    showSurvivor(remains);
    setTankRemainsVector(tanks);

    //定時生成enemy(call generateEnemy)
    spawnTimer = new QTimer(this);
    generateEnemy(level); // 先生成一個初始敵人
    connect(spawnTimer, &QTimer::timeout, this, [this, level](){
        generateEnemy(level);
    });
    isTimerPaused = false;
    spawnTimer->start(8000); // 2000 改成 8000
    // Create the score
    score = new Score();
    addItem(score);
    // Create the health
    health = new Health();
    health->setPos(health->x(), health->y() + 25);
    addItem(health);

    keyRespondTimer1 = new QTimer(this);
    connect(keyRespondTimer1, &QTimer::timeout, this, &Level::slotTimeOut1);
    powerup.setZValue(1000);
    addItem(&powerup);

    connect(effectTimer, &QTimer::timeout, this, &Level::togglePlayerOpacity);
    connect(invincibleTimer, &QTimer::timeout, this, &Level::setInvincibe);
    connect(invincibleTimer, &QTimer::timeout, this, [=]() {
    effectTimer->stop();
});
    checkTimer->start(50);
    connect(checkTimer, &QTimer::timeout, this, [=]() {
    if (!invincible)
    checkBulletPlayerCollision();
    });
    shootTimer = new QTimer(this);
    connect(shootTimer, &QTimer::timeout, this, &Level::resetShootStatus);

}
void Level::handleShovelEffect()
{

    QVector<QPair<int, int>> positionsToModify = {
        {48, 20}, {49, 20}, {50, 20}, {51, 20},
        {48, 21}, {49, 21}, {50, 21}, {51, 21},
        {48, 22}, {49, 22}, {50, 22}, {51, 22},
        {48, 23}, {49, 23}, {50, 23}, {51, 23},
        {48, 28}, {49, 28}, {50, 28}, {51, 28},
        {48, 29}, {49, 29}, {50, 29}, {51, 29},
        {48, 30}, {49, 30}, {50, 30}, {51, 30},
        {48, 31}, {49, 31}, {50, 31}, {51, 31},
    };
    for (int row = 46; row <= 47; ++row) {
        for (int col = 20; col <= 31; ++col) {
            positionsToModify.append({row, col});
        }
    }
    qDebug() << "positionsToModify );";
    for (auto position : positionsToModify)
    {
        int row = position.first;
        int col = position.second;
        qDebug() << "positionsToModify );"<<row;
        qDebug() << "positionsToModify );"<<col;
        if (row >= 0 && row < matrix.size() && col >= 0 && col < matrix[row].size())
        {
            QList<QGraphicsItem*> itemList = items(QRectF(col * 15,row * 15, 15, 15), Qt::IntersectsItemBoundingRect);
            for (QGraphicsItem* item : itemList) {

                if (Wall* wall = dynamic_cast<Wall*>(item))
                {
                    removeItem(wall);
                    delete wall;
                }
            }
        }
    }
    qDebug() << " removeItem(wall); );";
    for (auto position : positionsToModify)
    {
        int row = position.first;
        int col = position.second;

        if (row >= 0 && row < matrix.size() && col >= 0 && col < matrix[row].size())
        {
            Wall *wall = new Wall('s');
            addItem(wall);
            wall->setPos(col*15, row*15);
            connect(wall, &Wall::breakWall, this, &Level::hitOnWall);
            connect(wall, &Wall::wallBlockTank, this, &Level::encounterWall);
        }
    }
    qDebug() << "  Wall *wall = new Wall('s');;";
    QTimer::singleShot(5000, [=]() {
        for (auto position : positionsToModify)
        {
            int row = position.first;
            int col = position.second;

            Wall *wall = new Wall('b');
            addItem(wall);
            wall->setPos(col*15 , row*15);
            connect(wall, &Wall::breakWall, this, &Level::hitOnWall);
            connect(wall, &Wall::wallBlockTank, [=](){
            encounterWall(wall);
            player->setPos(player->getPrev());

            });
        }
    });

    qDebug() << "Wall *wall = new Wall('b');;";
}

void Level::setPlayer(int number)
{
    if(number==1){
        player = new Player();
        player->setPos(200, 550);
        addItem(player);
        qDebug() << "addItem(player);";

        invincible=true;
        qDebug() << "invincible=true;";
        player->setOpacity(0.5);
        qDebug() << "player->setOpacity(0.5);";
        effectTimer->start(500);
        if (invincible)
        invincibleTimer->start(3000);

    }else{
        player = new Player();
        player->setPos(200, 550);
        addItem(player);
        player2 = new Player2();
        player2->setPos(600, 550); // 根據您的需求設定初始位置
        addItem(player2);


        invincible=true;
        qDebug() << "invincible=true;";
        player->setOpacity(0.5);
        qDebug() << "player->setOpacity(0.5);";
        effectTimer->start(500);
        if (invincible)
        invincibleTimer->start(3000);
    }

}

void Level::increaseScore(Bullet *bullet, Enemy *enemy)
{
    removeItem(bullet);
    delete bullet;

    if (tankType == 'a') { // 如果是Armor Tank
        enemy->hits++;
        qDebug() << "Armor Tank hits: " << enemy->hits;

        // 檢查是否被射擊了四次
        if (enemy->hits >= 4) {
        removeItem(enemy);
        delete enemy;
        }
    } else {
        // 如果是其他坦克類型，直接刪除
        removeItem(enemy);
        delete enemy;
    }
    //removeItem(enemy);
    //delete enemy;
    //score->increase();
}

void Level::hitOnWall(Wall *wall, Bullet *bullet)
{
    //qDebug() << wall->getTypeIndex();
    switch(wall->getTypeIndex()){
        case 0:
            removeItem(bullet);
            delete bullet;
            removeItem(wall);
            delete wall;
            break;
        case 1:
            removeItem(bullet);
            delete bullet;
            break;
        default:
            break;
    }
}

void Level::encounterWall(Wall *wall)
{

    //player->setPos1(player->pos()); // pos1 紀錄移動前

    switch(wall->getTypeIndex()){
        case 0:
        case 1:
        case 3:
            player->setColliding(true);
            player->setPos(player->getPrev()); // 把圖片退回前一步
//           player->setColliding(false);
            break;
        default:
            break;
    }
}


void Level::keyReleaseEvent(QKeyEvent *event) {
    if (!event->isAutoRepeat()) {
            keys.removeAll(event->key());
    }
    if (keys.isEmpty()) {
            keyRespondTimer1->stop();
    }
}

void Level::keyPressEvent(QKeyEvent *event) {
    if (event->key() == Qt::Key_Space && !BulletFired) {

            Bullet *bullet = new Bullet(10);
            if (star>=1)
                bullet-> setBulletSpeed(30);
            BulletFired = true;   //空白建間格
            shootTimer->start(500);
            connect(bullet, &Bullet::bulletHitsEnemy, this, &Level::increaseScore);
            //bullet->setPos(player->pos());
            switch (player->current_player_Direction) {
            case 3:
            bullet->setPos(player->x() + player->pixmap().width() / 2 - bullet->pixmap().width() / 2, player->y());
            break;
                case 4:
            bullet->setPos(player->x() + player->pixmap().width() / 2 - bullet->pixmap().width() / 2, player->y() + player->pixmap().height() - bullet->pixmap().height());
            break;
                case 1:
            bullet->setPos(player->x(), player->y() + player->pixmap().height() / 2 - bullet->pixmap().height() / 2);
            break;
                case 2:
            bullet->setPos(player->x() + player->pixmap().width() - bullet->pixmap().width(), player->y() + player->pixmap().height() / 2 - bullet->pixmap().height() / 2);
            break;
                default:
            break;
            }
            if(star>=3)
            {
             Bullet *vbullet = new Bullet(30);
             vbullet->setOpacity(0);
             vbullet->setPos(bullet->x() + (player->current_player_Direction == 2 ?1: (player->current_player_Direction == 1 ? -1 : 0)),
                             bullet->y() + (player->current_player_Direction == 4 ? 1 : (player->current_player_Direction == 3 ? -1: 0)));
             vbullet->setCurrentDirection(player->current_player_Direction);
             addItem(vbullet);
            }
            bullet->setCurrentDirection(player->current_player_Direction);
            addItem(bullet);
            if (star >= 2) {
                Bullet *secondBullet = new Bullet(30);
                // Position the second bullet in the same direction as the first bullet
                secondBullet->setPos(bullet->x() + (player->current_player_Direction == 2 ? 10 : (player->current_player_Direction == 1 ? -10 : 0)),
                                     bullet->y() + (player->current_player_Direction == 4 ? 10 : (player->current_player_Direction == 3 ? -10 : 0)));

                secondBullet->setCurrentDirection(player->current_player_Direction);
                addItem(secondBullet);
                if(star>=3)
                {
                Bullet *vbullet2 = new Bullet(30);
                vbullet2->setOpacity(0);
                vbullet2->setPos(secondBullet->x() + (player->current_player_Direction == 2 ?1: (player->current_player_Direction == 1 ? -1 : 0)),
                                 secondBullet->y() + (player->current_player_Direction == 4 ? 1 : (player->current_player_Direction == 3 ? -1: 0)));
                vbullet2->setCurrentDirection(player->current_player_Direction);
                addItem(vbullet2);
                }
            }

    }
    if(number_1==2){
            if (event->key() == Qt::Key_Q) {
        Bullet *bullet = new Bullet(10);
        connect(bullet, &Bullet::bulletHitsEnemy, this, &Level::increaseScore);
        //bullet->setPos(player->pos());

        switch (player2->current_player2_Direction) {
        case 3:
                bullet->setPos(player2->x() + player2->pixmap().width() / 2 - bullet->pixmap().width() / 2, player2->y());
                break;
        case 4:
                bullet->setPos(player2->x() + player2->pixmap().width() / 2 - bullet->pixmap().width() / 2, player2->y() + player2->pixmap().height() - bullet->pixmap().height());
                break;
        case 1:
                bullet->setPos(player2->x(), player2->y() + player2->pixmap().height() / 2 - bullet->pixmap().height() / 2);
                break;
        case 2:
                bullet->setPos(player2->x() + player2->pixmap().width() - bullet->pixmap().width(), player2->y() + player2->pixmap().height() / 2 - bullet->pixmap().height() / 2);
                break;
        default:
                break;
        }
        bullet->setCurrentDirection(player2->current_player2_Direction);
        addItem(bullet);}

    }

    if (!event->isAutoRepeat()) {
            keys.append(event->key());
    }
    if (!keyRespondTimer1->isActive()) {
            keyRespondTimer1->start(4);
    }
}

void Level::slotTimeOut1() {

    //player->keyPressEvent1(keys); // 這裡處理player1的按鍵事件
    foreach (int key, keys){
            QPointF pos = player->pos();  // Assuming 'player' is the current instance
            player->setPrev(pos); // prev 相當於記移動前的位置
            player->setTransformOriginPoint(player->boundingRect().center());
            QPointF nextpos = pos;

            if (key == Qt::Key_Left ) {
        player->current_player_Direction = 1;
        player->setRotation(180); // 左邊
        nextpos = pos + QPointF(-2, 0);
            } else if (key == Qt::Key_Right) {
        player->current_player_Direction = 2; // 改變方向為右邊
        player->setRotation(0); // 右邊
        nextpos = pos + QPointF(2, 0);
            } else if (key == Qt::Key_Up) {
        player->current_player_Direction = 3;
        player->setRotation(-90); // 上面
        nextpos = pos + QPointF(0, -2);
            } else if (key == Qt::Key_Down) {
        player->current_player_Direction = 4;
        player->setRotation(90); // 下面
        nextpos = pos + QPointF(0, 2);
            }
            player->setPos1(nextpos);
            checkPlayerWallCollision(player, player->current_player_Direction);

            //        if (player->getColliding()) {
            //            player->setPos1(player->getPrev());
            //            player->setColliding(false);
            //        }
            //        else {
            //            player->setPos1(nextpos);
            //            qDebug() << nextpos << player->pos() << "prev = " << player->getPrev();
            //        }

            //        if (player->getPos1() == player->getPrev()){
            //            player->setColliding(false);
            //        }
            player->setPos(player->getPos1());


            // player->keyPressEvent1(key);


            if(number_1==2){
        player2->keyPressEvent2(key); // 這裡處理player2的按鍵事件
        }
            checkPowerupCollision();
    }
}
void Level::generateMap(int level)
{
    //map 19
    vector<string> data;
    if (level == 1) {
        data = {
            "****####****####****####****####****####****####****",//layer1
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****",
            "****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****",
            "****************************************************",
            "****************************************************",
            "****************####************####****************",//layer2
            "****************####************####****************",
            "####****####****####************####****####****####",
            "####****####****####************####****####****####",
            "####****############****####****############****####",
            "####****############****####****############****####",
            "####****####****####****####****####****####****####",
            "####****####****####****####****####****####****####",
            "&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&",
            "&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&",
            "****************&&&&************&&&&****************",
            "****************&&&&************&&&&****************",
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",//layer3
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",
            "%%%%%%%%%%%%%%%%########%%%%########%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%########%%%%########%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%####****%%%%****####%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%####****%%%%****####%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "****************####%%%%%%%%%%%%####****************",
            "****************####%%%%%%%%%%%%####****************",
            "####****####****####%%%%%%%%%%%%####****####****####",
            "####****####****####%%%%%%%%%%%%####****####****####",
            "****####****####********%%%%********####****####****",//layer4
            "****####****####********%%%%********####****####****",
            "****####****####********%%%%********####****####****",
            "****####****####********************####****####****",
            "****####****####********************####****####****",
            "****####****####****############****####****####****",
            "****####****####****############****####****####****",
            "****####****####****####f***####****####****####****",
            "****####****####****####****####****####****####****",
            "********************####****####********************",
            "********************####****####********************"
        };
    } else {
        //map 28
        data = {
            "****************************************************",
            "****************************************************",
            "****************************************************",
            "****************************************************",
            "****************####****####************************",
            "****************####****####************************",
            "****************####****####************************",
            "****************####****####************************",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "################&&&&####&&&&################%%%%****",
            "################&&&&####&&&&################%%%%****",
            "################&&&&####&&&&################%%%%****",
            "################&&&&####&&&&################%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@####################################@@@@@@@@%%%%",
            "@@@@####################################@@@@@@@@%%%%",
            "@@@@####################################@@@@@@@@%%%%",
            "@@@@####################################@@@@@@@@%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****************************************************",
            "****************************************************",
            "********************############********************",
            "********************############********************",
            "********************####f***####********************",
            "********************####****####********************",
            "********************####****####********************",
            "********************####****####********************"
        };
    }

    //存成二維陣列
    for (const string& row : data) {
        vector<char> rowVector(row.begin(), row.end());
        matrix.push_back(rowVector);
    }

    float i = 0;
    float j = 0;

    //setPos
    for (const auto& rowVector : matrix) {
        i = 0; //寫完一row就回到0
        for (char element : rowVector) {
            if (element == '#') {
                Wall *wall = new Wall('b');
                addItem(wall);
                wall->setPos(i ,j);
                connect(wall, &Wall::breakWall, this, &Level::hitOnWall);
                connect(wall, &Wall::wallBlockTank, [=](){
                    encounterWall(wall);
                    player->setPos(player->getPrev()); // 把圖片退回前一步
                });
            } else if (element == '&') {
                Wall *wall = new Wall('s');
                addItem(wall);
                wall->setPos(i, j);
                connect(wall, &Wall::breakWall, this, &Level::hitOnWall);
                connect(wall, &Wall::wallBlockTank, this, &Level::encounterWall);
            } else if (element == '%') {
                Wall *wall = new Wall('t');
                addItem(wall);
                wall->setPos(i, j);
            } else if (element == '@') {
                Wall *wall = new Wall('w');
                addItem(wall);
                wall->setPos(i, j);
                connect(wall, &Wall::wallBlockTank, this, &Level::encounterWall);
            } else if (element == '$') {
                Wall *wall = new Wall('i');
                addItem(wall);
                wall->setPos(i, j);
            } else if (element == 'f') {
                Flag *flag = new Flag();
                addItem(flag);
                flag->setPos(370, 740);
            } else {
                i+=800/52; //這裡還要再根據圖片大小做調整
                continue;  //空白，不用放東西
            }
            i += 800/52; //這裡還要再根據圖片大小做調整
        }
        j += 800/52;       //這裡還要再根據圖片大小做調整
    }

}

void Level::setTankRemainsVector(const vector<vector<char> > &tankRemains)
{
    tanks = tankRemains;
}

const vector<vector<char> > &Level::getTankRemainsVector() const
{
    return tanks;
}

void Level::generateEnemy(int level)
{

    //用connect,當timeout就生成一隻tank
    getTankRemainsVector();


    //並將其從vector裡刪除
    if(!tanks[level-1].empty())
    {

        tankType = tanks[level - 1].front();
        Enemy *enemy = new Enemy();

        switch (tankType)
        {
        case 'f':
            enemy->setPixmap(QPixmap(":/images/Enemies/Fast_Tank.png").scaled(40, 40));
            enemy->moveSpeed=30;
            enemy->bulletSpeed=20;
            break;
        case 'a':
            enemy->setPixmap(QPixmap(":/images/Enemies/Armor_Tank.png").scaled(40, 40));
            enemy->moveSpeed=20;
            enemy->bulletSpeed=20;
            //tankType='a';
            break;
        case 'b':
            enemy->setPixmap(QPixmap(":/images/Enemies/Basic_Tank.png").scaled(40, 40));
            enemy->moveSpeed=10;
            enemy->bulletSpeed=10;
            break;
        case 'p':
            enemy->setPixmap(QPixmap(":/images/Enemies/Power_Tank.png").scaled(40, 40));
            enemy->moveSpeed=30;
            enemy->bulletSpeed=30;
            break;
        default:
            break;
        }
        addItem(enemy);
        enemyList.append(enemy);
        qDebug()<<"delete picture...";
        tanks[level-1].erase(tanks[level-1].begin());
        setTankRemainsVector(tanks);
    }
    else
    {
        qDebug()<<"finish deleting";
        spawnTimer->stop();
    }

    if (!isEnemyMovementFrozen)
    {
        setInitialEnemySpeed();  // Set the initial speed for enemies
    }

}
void Level::checkPlayerWallCollision(Player *player, int playerDir) {
    QPointF pos = player->pos();
    QPointF nextpos = player->getPos1();  // 玩家下一步的位置

    // 遍歷所有牆，看是否與玩家發生碰撞
    for (QGraphicsItem *item : items()) {
        Wall *wall = dynamic_cast<Wall*>(item);
        if (wall) {
            switch(wall->getTypeIndex()){
            case 0:
            case 1:
                // 如果以下情況，阻止玩家移動
                // 1. 若往左走小於牆的x
                // 2. 若往右走大於牆的x
                // 3. 若往上走小於牆的y
                // 4. 若往下走大於牆的y
                if (nextpos.x() < wall->pos().x() + wall->boundingRect().width() &&
                    nextpos.x() + player->pixmap().width() > wall->pos().x() &&
                    nextpos.y() < wall->pos().y() + wall->boundingRect().height() &&
                    nextpos.y() + player->pixmap().height() > wall->pos().y()) {
                    player->setPos1(pos);  // 玩家位置還原當前位置
                    return;
                }
            }
        }
    }
}
//還要寫個刪除所有圖片的
void Level::showSurvivor(int remains)
{
    int x=740;
    int y=60;
    //生成初始ramaining survivors，共20台，10*2
    for (int i=1; i<=remains/2; i++){
        for (int j=1; j<=2; j++){
            survivors = new QGraphicsPixmapItem(QPixmap(":/images/Enemies/Remains.png"));
            survivors->setPos(x, y);
            addItem(survivors);
            x+=10;
            y+=40;
        }
        x-=20;
    }
    //處理最後一排(mod為奇數時進入)
    for (int k = 1; k <= remains % 2; k++) {
        y+=40;
        survivors = new QGraphicsPixmapItem(QPixmap(":/images/Enemies/Remains.png"));
        survivors->setPos(x, y);
        addItem(survivors);
    }
}
void Level::checkPowerupCollision() {
    QList<QGraphicsItem *> collidingItems = player->collidingItems();

    for (QGraphicsItem *item : collidingItems) {
        if (item == &powerup) {
            handlePowerupCollision();
            break;
        }
    }
}

void Level::handlePowerupCollision() {
    switch (powerup.type){
    case 0: handleGrenadeEffect();
    case 1: handleHelmatEffect();
    case 2: handleShovelEffect();
    case 3: handleStarEffect();
    case 4: handleTankEffect();
    case 5: handleTimerEffect();
    break;
    default:
    qDebug() << "Unknown power-up type!";
    }
    removeItem(&powerup);
}
