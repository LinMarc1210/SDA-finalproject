#ifndef PLAYER_H
#define PLAYER_H

#include "Bullet.h"
#include "Enemy.h"
#include <QObject>
#include <QGraphicsPixmapItem>
#include <QTimer>
class Player :  public QGraphicsPixmapItem
{
public:
    Player();
    void keyPressEvent1(int key);
    void increaseScore(Bullet *bullet, Enemy *enemy);
    int current_player_Direction=2;

    QPointF getPrev() const;
    void setPrev(QPointF newPrev);
    QPointF getPos1() const;
    void setPos1(QPointF newPos);

    bool getColliding() const;
    void setColliding(bool newColliding);



private:
    Player *player;
    QPointF prev;
    QPointF pos1;
    bool colliding = false;

};

#endif // PLAYER_H
