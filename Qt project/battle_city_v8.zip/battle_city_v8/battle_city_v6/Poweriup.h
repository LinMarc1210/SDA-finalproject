#ifndef POWERIUP_H
#define POWERIUP_H


class Poweriup
{
public:
    Poweriup();
    random
};

#endif // POWERIUP_H
