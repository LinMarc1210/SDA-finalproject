#include "player2.h"
#include <QKeyEvent>

Player2::Player2()
{
    setPixmap(QPixmap(":/images/Players/Player2.png").scaled(40,40));
}
