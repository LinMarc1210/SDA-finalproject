#ifndef PLAYER2_H
#define PLAYER2_H
#include <QGraphicsPixmapItem>

class Player2: public QGraphicsPixmapItem
{
public:
    Player2();
    int current_player2_Direction=1;
};

#endif // PLAYER2_H
