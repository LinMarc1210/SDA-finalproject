#ifndef PLAYER2_H
#define PLAYER2_H
#include <QGraphicsPixmapItem>

class Player2: public QGraphicsPixmapItem
{
public:
    Player2();
    int current_player2_Direction=1;
    void keyPressEvent2(int key);
};

#endif // PLAYER2_H
