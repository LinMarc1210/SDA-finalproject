#include "Player.h"

Player::Player()
{
    setPixmap(QPixmap(":/images/Players/Player1.png"));
}
