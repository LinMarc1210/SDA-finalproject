#ifndef LEVEL_H
#define LEVEL_H

//#include "Enemy.h"
#include <vector>
#include <QTimer>
#include <QObject>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>

#include "Bullet.h"
#include "Health.h"
#include "Player.h"
#include "Player2.h"
#include "Score.h"

using namespace std;

class Level : public QGraphicsScene
{
    Q_OBJECT
public:
    Level(int =0, int =0); //接收scene傳來的level跟number of players
    //void setPlayer(int number);
    void generateMap(int level);
    bool gamePause();//目前不寫
    void saveGame(); //目前不知怎麼搞
    void showGameover();//最後再寫
    void showSurvivor(int remains);     //生成畫面右邊的坦克剩餘圖

    void setTankRemainsVector(const vector<vector<char>>& tankRemains);
    const vector<vector<char>>& getTankRemainsVector() const;

    int current_player_Direction=3;
    int current_player2_Direction=3;

public slots:
    //void generateEnemy(int level);

    void spawnEnemy();
    void increaseScore(Bullet *bullet, Enemy *enemy);
    void decreaseHealth(Enemy *enemy);


private:
    int level;    //等級
    int number;   //player人數
    int remains;
    vector<vector<char>> tanks;

    QGraphicsPixmapItem *survivors;
    //QGraphicsPixmapItem *player1;
    //QGraphicsPixmapItem *player2;

    QTimer *spawnTimer;

    Player *player;
    Player2 *player2;
    QTimer *timer;
    Score *score;
    Health *health;


protected:
    //void keyPressEvent(QKeyEvent *event);
    void keyPressEvent1(QKeyEvent *event) ;
        // 這裡是處理第一個按鍵事件的程式
    void keyPressEvent2(QKeyEvent *event) ;
        // 這裡是處理第二個按鍵事件的程式碼
    void keyPressEvent(QKeyEvent *event) override ;

};


#endif // LEVEL_H
