#include "player2.h"

Player2::Player2()
{
    setPixmap(QPixmap(":/images/Players/Player2.png"));
}
