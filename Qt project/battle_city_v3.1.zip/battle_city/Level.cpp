#include "Wall.h"
#include "Flag.h"
#include "Level.h"
#include <QDebug>

#include "Bullet.h"
#include "Enemy.h"
#include "Scene.h"
#include <QGraphicsRectItem>
#include <QKeyEvent>
#include <QGraphicsPixmapItem>
#include "Player.h"
#include "Player2.h"

Level::Level(int level, int number)
    :remains(20),
    tanks({{'f', 'f', 'f', 'f', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'b', 'b', 'b', 'b', 'p', 'p', 'p', 'p'},
           {'p', 'p', 'p', 'p', 'f', 'f', 'f', 'f', 'f', 'f', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'b', 'b'}})
{
    //setPlayer(number); //決定幾個玩家並生成在初始位置
    generateMap(level);
    //showSurvivor(remains);
    setTankRemainsVector(tanks);

    //定時生成enemy(call generateEnemy)
    /*spawnTimer = new QTimer(this);
    connect(spawnTimer, &QTimer::timeout, this, [this, level](){
        generateEnemy(level);
    });
    spawnTimer->start(2000);*/

    // Create a QGraphicsRectItem (a QGraphicsItem representing a rect)
    player = new Player();
    player->setPos(350, 500);
    addItem(player);

    player2 = new Player2();
    player2->setPos(550, 500); // 根據您的需求設定初始位置
    addItem(player2);

    // Create the score
    score = new Score();
    addItem(score);

    // Create the health
    health = new Health();
    health->setPos(health->x(), health->y() + 25);
    addItem(health);

    // Randomly spawn enemies every 2s
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &Level::spawnEnemy);
    timer->start(5000); // 2s
}

/*void Level::setPlayer(int number)
{
    if(number==1){
        player1 = new QGraphicsPixmapItem(QPixmap(":/images/Players/Player1.png").scaled(60,60));
        player1->setPos(200, 550);
        addItem(player1);
    }else{
        player1 = new QGraphicsPixmapItem(QPixmap(":/images/Players/Player1.png").scaled(60,60));
        player1->setPos(200, 550);
        addItem(player1);

        player2 = new QGraphicsPixmapItem(QPixmap(":/images/Players/Player2.png").scaled(60,60));
        player2->setPos(600, 550);
        addItem(player2);
    }
}*/


void Level::spawnEnemy() {
    // Create an enemy
    Enemy *enemy = new Enemy();
    connect(enemy, &Enemy::enemyHitsTheGround, this, &Level::decreaseHealth);
    addItem(enemy);
}

void Level::increaseScore(Bullet *bullet, Enemy *enemy)
{
    removeItem(bullet);
    delete bullet;
    removeItem(enemy);
    delete enemy;
    score->increase();
}

void Level::decreaseHealth(Enemy *enemy)
{
    removeItem(enemy);
    delete enemy;
    health->decrease();
}


void Level::keyPressEvent1(QKeyEvent *event)
{
    qDebug() << "Scene knows you pressed a key";
    QPointF pos = player->pos();
    player->setTransformOriginPoint(player->boundingRect().center());
    if (event->key() == Qt::Key_Left && pos.x() > 0) {
        current_player_Direction = 1;
        player->setRotation(-90); // 左邊
        player->setPos(pos + QPointF(-10, 0));
    } else if (event->key() == Qt::Key_Right && pos.x() < 700) {
        current_player_Direction = 2; // 改變方向為右邊
        player->setRotation(90); // 右邊
        player->setPos(pos + QPointF(10, 0));
    } else if (event->key() == Qt::Key_Up) {
        current_player_Direction = 3;
        player->setRotation(0); // 上面
        player->setPos(pos + QPointF(0, -10));
    } else if (event->key() == Qt::Key_Down) {
        current_player_Direction = 4;
        player->setRotation(180); // 下面
        player->setPos(pos + QPointF(0, 10));
    }

    if (event->key() == Qt::Key_Space) {
        Bullet *bullet = new Bullet();
        connect(bullet, &Bullet::bulletHitsEnemy, this, &Level::increaseScore);
        //bullet->setPos(player->pos());

        switch (current_player_Direction) {
        case 3:
            bullet->setPos(player->x() + player->pixmap().width() / 2 - bullet->pixmap().width() / 2, player->y());
            break;
        case 4:
            bullet->setPos(player->x() + player->pixmap().width() / 2 - bullet->pixmap().width() / 2, player->y() + player->pixmap().height() - bullet->pixmap().height());
            break;
        case 1:
            bullet->setPos(player->x(), player->y() + player->pixmap().height() / 2 - bullet->pixmap().height() / 2);
            break;
        case 2:
            bullet->setPos(player->x() + player->pixmap().width() - bullet->pixmap().width(), player->y() + player->pixmap().height() / 2 - bullet->pixmap().height() / 2);
            break;
        default:
            break;
        }
        bullet->setCurrentDirection(current_player_Direction);
        addItem(bullet);
    }
}

void Level::keyPressEvent2(QKeyEvent *event)
{
    //part2
    QPointF pos2 = player2->pos();
    player2->setTransformOriginPoint(player2->boundingRect().center());
    if (event->key() == Qt::Key_A && pos2.x() > 0) {
        current_player2_Direction = 1;
        player2->setRotation(-90); // 左邊
        player2->setPos(pos2 + QPointF(-10, 0));
    } else if (event->key() == Qt::Key_D && pos2.x() < 700) {

        current_player2_Direction = 2; // 改變方向為右邊
        player2->setRotation(90); // 右邊
        player2->setPos(pos2 + QPointF(10, 0));
    } else if (event->key() == Qt::Key_W) {

        current_player2_Direction = 3;
        player2->setRotation(0); // 上面
        player2->setPos(pos2 + QPointF(0, -10));
    } else if (event->key() == Qt::Key_S) {

        current_player2_Direction = 4;
        player2->setRotation(180); // 下面
        player2->setPos(pos2 + QPointF(0, 10));
    }

    if (event->key() == Qt::Key_Q) {
        Bullet *bullet = new Bullet();
        connect(bullet, &Bullet::bulletHitsEnemy, this, &Level::increaseScore);
        //bullet->setPos(player->pos());

        switch (current_player2_Direction) {
        case 3:
            bullet->setPos(player2->x() + player2->pixmap().width() / 2 - bullet->pixmap().width() / 2, player2->y());
            break;
        case 4:
            bullet->setPos(player2->x() + player2->pixmap().width() / 2 - bullet->pixmap().width() / 2, player2->y() + player2->pixmap().height() - bullet->pixmap().height());
            break;
        case 1:
            bullet->setPos(player2->x(), player2->y() + player2->pixmap().height() / 2 - bullet->pixmap().height() / 2);
            break;
        case 2:
            bullet->setPos(player2->x() + player2->pixmap().width() - bullet->pixmap().width(), player2->y() + player2->pixmap().height() / 2 - bullet->pixmap().height() / 2);
            break;
        default:
            break;
        }
        bullet->setCurrentDirection(current_player2_Direction);
        addItem(bullet);
    }
}

void Level::keyPressEvent(QKeyEvent *event) {
    keyPressEvent1(event); // 這裡處理player1的按鍵事件
    keyPressEvent2(event); // 這裡處理player2的按鍵事件
}

void Level::generateMap(int level)
{
    //map 19
    vector<string> data;
    qDebug() << "call...";
    if (level == 1) {
        data = {
            "****####****####****####****####****####****####****",//layer1
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****",
            "****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****",
            "****************************************************",
            "****************************************************",
            "****************####************####****************",//layer2
            "****************####************####****************",
            "####****####****####************####****####****####",
            "####****####****####************####****####****####",
            "####****############****####****############****####",
            "####****############****####****############****####",
            "####****####****####****####****####****####****####",
            "####****####****####****####****####****####****####",
            "&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&",
            "&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&",
            "****************&&&&************&&&&****************",
            "****************&&&&************&&&&****************",
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",//layer3
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",
            "%%%%%%%%%%%%%%%%########%%%%########%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%########%%%%########%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%####****%%%%****####%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%####****%%%%****####%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "****************####%%%%%%%%%%%%####****************",
            "****************####%%%%%%%%%%%%####****************",
            "####****####****####%%%%%%%%%%%%####****####****####",
            "####****####****####%%%%%%%%%%%%####****####****####",
            "****####****####********%%%%********####****####****",//layer4
            "****####****####********%%%%********####****####****",
            "****####****####********%%%%********####****####****",
            "****####****####********************####****####****",
            "****####****####********************####****####****",
            "****####****####****############****####****####****",
            "****####****####****############****####****####****",
            "****####****####****####f***####****####****####****",
            "****####****####****####****####****####****####****",
            "********************####****####********************",
            "********************####****####********************"
        };
    } else {
        //map 28
        data = {
            "****************************************************",
            "****************************************************",
            "****************************************************",
            "****************************************************",
            "****************####****####************************",
            "****************####****####************************",
            "****************####****####************************",
            "****************####****####************************",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "################&&&&####&&&&################%%%%****",
            "################&&&&####&&&&################%%%%****",
            "################&&&&####&&&&################%%%%****",
            "################&&&&####&&&&################%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@####################################@@@@@@@@%%%%",
            "@@@@####################################@@@@@@@@%%%%",
            "@@@@####################################@@@@@@@@%%%%",
            "@@@@####################################@@@@@@@@%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****************************************************",
            "****************************************************",
            "********************############********************",
            "********************############********************",
            "********************####f***####********************",
            "********************####****####********************",
            "********************####****####********************",
            "********************####****####********************"
        };
    }

    //存成二維陣列
    vector<vector<char>> matrix;
    for (const string& row : data) {
        qDebug() << "transform...";
        vector<char> rowVector(row.begin(), row.end());
        matrix.push_back(rowVector);
    }

    float i = 0;
    float j = 0;

    //setPos
    for (const auto& rowVector : matrix) {
        i = 0; //寫完一row就回到0
        for (char element : rowVector) {
            if (element == '#') {
                Wall *wall = new Wall('b');
                addItem(wall);
                wall->setPos(i ,j);
                i+=800/52; //這裡還要再根據圖片大小做調整
            } else if (element == '$') {
                Wall *wall = new Wall('i');
                addItem(wall);
                wall->setPos(i, j);
                i+=800/52; //這裡還要再根據圖片大小做調整
            } else if (element == '&') {
                Wall *wall = new Wall('s');
                addItem(wall);
                wall->setPos(i, j);
                i+=800/52; //這裡還要再根據圖片大小做調整
            } else if (element == '%') {
                Wall *wall = new Wall('t');
                addItem(wall);
                wall->setPos(i, j);
                i+=800/52; //這裡還要再根據圖片大小做調整
            } else if (element == '@') {
                Wall *wall = new Wall('w');
                addItem(wall);
                wall->setPos(i, j);
                i+=800/52; //這裡還要再根據圖片大小做調整
            } else if (element == 'f') {
                Flag *flag = new Flag();
                addItem(flag);
                flag->setPos(370, 740);
                i+=800/52; //這裡還要再根據圖片大小做調整
            } else {
                i+=800/52; //這裡還要再根據圖片大小做調整
                continue;  //空白，不用放東西
            }
        }
        j += 800/52;       //這裡還要再根據圖片大小做調整
    }
}


void Level::setTankRemainsVector(const vector<vector<char> > &tankRemains)
{
    tanks = tankRemains;
}

const vector<vector<char> > &Level::getTankRemainsVector() const
{
    return tanks;
}
/*
void Level::generateEnemy(int level)
{
    //用connect,當timeout就生成一隻tank
    getTankRemainsVector();
    //Enemy *enemy= new Enemy(tanks[level-1][0]);

    //並將其從vector裡刪除
    if(!tanks[level-1].empty())
    {
        qDebug()<<"delete picture...";
        tanks[level-1].erase(tanks[level-1].begin());
        setTankRemainsVector(tanks);
    }
    else
    {
        qDebug()<<"finish deleting";
        spawnTimer->stop();
    }
    //showSurvivor(--remains);
}*/

//還要寫個刪除所有圖片的
void Level::showSurvivor(int remains)
{
    int x=740;
    int y=60;
    //生成初始ramaining survivors，共20台，10*2
    for (int i=1; i<=remains/2; i++){
        for (int j=1; j<=2; j++){
            survivors = new QGraphicsPixmapItem(QPixmap(":/images/Enemies/Remains.png"));
            survivors->setPos(x, y);
            addItem(survivors);
            x+=10;
            y+=40;
        }
        x-=20;
    }
    //處理最後一排(mod為奇數時進入)
    for (int k = 1; k <= remains % 2; k++) {
        y+=40;
        survivors = new QGraphicsPixmapItem(QPixmap(":/images/Enemies/Remains.png"));
        survivors->setPos(x, y);
        addItem(survivors);
    }
}
